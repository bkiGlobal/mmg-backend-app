// static/yourapp/js/admin/attendance_admin.js

(function () {
  // Helper: set Point WKT (POINT(lng lat)) ke input check_in_location / check_out_location
  function setPointWKT(inputId, lng, lat) {
    var el = document.getElementById(inputId);
    if (!el) {
      console.warn("Input not found:", inputId);
      return;
    }
    el.value = "POINT(" + lng + " " + lat + ")";
    // Jika widget merender peta, trigger change event supaya admin tahu ada perubahan
    var evt = new Event("change", { bubbles: true });
    el.dispatchEvent(evt);
  }

  // Ambil element file input (ID default Django = id_<fieldname>)
  var photoIn = document.getElementById("id_photo_check_in");
  var photoOut = document.getElementById("id_photo_check_out");

  // Kalau file input tidak ditemukan, keluar
  if (!photoIn && !photoOut) return;

  // Utility: enable/disable photo_out sesuai kondisi
  function updatePhotoOutState() {
    if (!photoOut) return;
    // jika sudah ada file di photo_in, enable photo_out; else disable
    var hasIn = photoIn && photoIn.files && photoIn.files.length > 0;
    if (hasIn) {
      photoOut.removeAttribute("disabled");
    } else {
      photoOut.setAttribute("disabled", "disabled");
    }
  }

  // Pasang atribut kamera pada runtime jikalau form widget lain menimpa
  try {
    if (photoIn) {
      photoIn.setAttribute("accept", "image/*");
      photoIn.setAttribute("capture", "user"); // usahakan kamera depan untuk selfie
    }
    if (photoOut) {
      photoOut.setAttribute("accept", "image/*");
      photoOut.setAttribute("capture", "user");
    }
  } catch (e) {
    console.warn("Cannot set capture attribute", e);
  }

  // Saat photo_check_in berubah: ambil geolocation dan isi check_in_location, enable photo_out
  if (photoIn) {
    photoIn.addEventListener("change", function (ev) {
      updatePhotoOutState();
      // Jika perangkat mendukung geolocation, minta posisi
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          function (position) {
            var lat = position.coords.latitude;
            var lng = position.coords.longitude;
            // NOTE: GeoDjango POINT format biasanya POINT(lng lat)
            setPointWKT("id_check_in_location", lng, lat);
          },
          function (err) {
            console.warn("Geolocation error (check-in):", err);
            // fallback: biarkan kosong dan admin bisa mengisi (untuk superuser)
            alert(
              "Tidak bisa mendapatkan lokasi. Pastikan izin lokasi diaktifkan."
            );
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0,
          }
        );
      } else {
        alert("Geolocation tidak didukung pada perangkat ini.");
      }
    });

    // inisialisasi status photo_out pada load
    document.addEventListener("DOMContentLoaded", updatePhotoOutState);
  }

  // Saat photo_check_out berubah: ambil geolocation dan isi check_out_location
  if (photoOut) {
    photoOut.addEventListener(
      "change",
      function (ev) {
        // Pastikan photo_in sudah ada (defense-in-depth)
        var hasIn = photoIn && photoIn.files && photoIn.files.length > 0;
        if (!hasIn) {
          alert(
            "Silakan lakukan check-in (selfie) terlebih dahulu sebelum check-out."
          );
          photoOut.value = ""; // kosongkan
          updatePhotoOutState();
          return;
        }

        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            function (position) {
              var lat = position.coords.latitude;
              var lng = position.coords.longitude;
              setPointWKT("id_check_out_location", lng, lat);
            },
            function (err) {
              console.warn("Geolocation error (check-out):", err);
              alert(
                "Tidak bisa mendapatkan lokasi. Pastikan izin lokasi diaktifkan."
              );
            },
            {
              enableHighAccuracy: true,
              timeout: 10000,
              maximumAge: 0,
            }
          );
        } else {
          alert("Geolocation tidak didukung pada perangkat ini.");
        }
      },
      false
    );
  }
})();
