document.addEventListener("DOMContentLoaded", function () {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function (position) {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;

      // Auto-masukkan ke field location jika field ada
      const checkInField = document.getElementById("id_check_in_location");
      const checkOutField = document.getElementById("id_check_out_location");
      const point = `POINT(${lon} ${lat})`;

      if (checkInField && !checkInField.value) {
        checkInField.value = point;
      } else if (checkOutField && !checkOutField.value) {
        checkOutField.value = point;
      }
    });
  } else {
    alert("Geolocation is not supported by this browser.");
  }
});
